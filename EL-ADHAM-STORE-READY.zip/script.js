const products = [
  {name:"ELADHAM Angel — أسود", price:700, images:["images/tshirt1-front.jpg","images/tshirt1-back.jpg"]},
  {name:"ELADHAM Graphic — أسود", price:700, images:["images/tshirt2-front.jpg","images/tshirt2-back.jpg"]},
  {name:"ELADHAM Blue — أزرق", price:700, images:["images/tshirt3-front.jpg","images/tshirt3-back.jpg"]},
  {name:"ELADHAM Angel Red — أسود", price:700, images:["images/tshirt4-front.jpg","images/tshirt4-back.jpg"]},
  {name:"ELADHAM Store — أبيض", price:700, images:["images/tshirt5-front.jpg","images/tshirt5-back.jpg"]}
];

const grid = document.getElementById("grid");

products.forEach((p,i)=>{
  const c=document.createElement("article");
  c.className="card";
  c.innerHTML=`
    <div class="photos">
      ${p.images.map((src,j)=>`
        <div class="photo-wrap" onclick="swapImage(${i},${j})">
          <img id="img-${i}-${j}" src="${src}" alt="${p.name} ${j===0?'أمام':'خلف'}">
          <span class="tag">${j===0?'الأمام':'الخلف'}</span>
        </div>`).join("")}
    </div>
    <div class="body">
      <h3>${p.name}</h3>
      <div class="meta">المقاسات: M / L / XL / 2XL</div>
      <div class="price">${p.price} جنيه</div>
      <div class="controls">
        <select id="s${i}">
          <option value="">اختار المقاس</option>
          <option>M</option><option>L</option><option>XL</option><option>2XL</option>
        </select>
        <input id="q${i}" type="number" min="1" value="1">
      </div>
      <button class="buy" onclick="order(${i})">اطلب على واتساب</button>
    </div>`;
  grid.appendChild(c);
});

function swapImage(i,j){
  const img=document.getElementById(`img-${i}-${j}`);
  const current=img.dataset.zoom;
  if(current==="1"){
    img.style.objectFit="cover";
    img.dataset.zoom="0";
  }else{
    img.style.objectFit="contain";
    img.dataset.zoom="1";
  }
}

function order(i){
  const size=document.getElementById("s"+i).value;
  const qty=Math.max(1,parseInt(document.getElementById("q"+i).value)||1);
  if(!size){alert("اختار المقاس الأول 👕");return}
  const p=products[i];
  const msg=`السلام عليكم، عايز أطلب:\nالمنتج: ${p.name}\nالمقاس: ${size}\nالكمية: ${qty}\nالإجمالي: ${p.price*qty} جنيه`;
  window.location.href="https://wa.me/201027380152?text="+encodeURIComponent(msg);
}
