const products = [
  {title:"تيشرت Angel — أسود", imgs:[1,2]},
  {title:"تيشرت EL ADHAM — أسود", imgs:[3,4]},
  {title:"تيشرت EL ADHAM — أسود", imgs:[5,6]},
  {title:"تيشرت ALADHAM — أسود", imgs:[7,8]},
  {title:"تيشرت EL ADHAM — أبيض", imgs:[9,10]},
  {title:"تيشرت White Edition", imgs:[11]},
  {title:"تيشرت Complicated Life — أبيض", imgs:[12,13]}
];

const grid = document.getElementById("grid");
products.forEach((p, i) => {
  const card = document.createElement("article");
  card.className = "card" + (p.imgs.length === 1 ? " single" : "");
  card.innerHTML = `
    <div class="gallery">
      ${p.imgs.map((n, j) => `<img src="images/tshirt-${n}.jpg" alt="${p.title} ${j===0?'وش':'ضهر'}" loading="${i<2?'eager':'lazy'}">`).join("")}
    </div>
    <div class="card-body">
      <h3 class="card-title">${p.title}</h3>
      <div class="card-meta">${p.imgs.length > 1 ? "وش + ضهر" : "تصميم أمامي"} • المقاسات M إلى 2XL</div>
      <div class="price">700 جنيه</div>
      <a class="buy" href="https://wa.me/201027380152?text=${encodeURIComponent("السلام عليكم، عايز أطلب " + p.title + " — مقاس: ")}" target="_blank" rel="noopener">اطلب على واتساب</a>
    </div>`;
  grid.appendChild(card);
});

const modal = document.getElementById("modal");
const modalImg = document.getElementById("modalImg");
document.addEventListener("click", e => {
  if (e.target.matches(".gallery img")) {
    modalImg.src = e.target.src;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden","false");
  }
});
document.querySelector(".close").onclick = () => {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden","true");
};
modal.addEventListener("click", e => {
  if (e.target === modal) document.querySelector(".close").click();
});
